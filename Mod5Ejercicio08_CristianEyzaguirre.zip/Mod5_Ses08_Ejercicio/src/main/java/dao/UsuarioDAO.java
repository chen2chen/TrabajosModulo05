package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Usuario;
import utils.GeneraPoolConexion;

public class UsuarioDAO {
	
	
public List<Usuario> listar() {
		
		List<Usuario> usuarios = new ArrayList<>();
		String sql="select * from usuario";
		
		Connection conn= null;
		Statement stmt= null;
		
		try {
	         //conectar a la BD
			  conn = GeneraPoolConexion.getConexion();
	          stmt = conn.createStatement();
	          ResultSet rs = stmt.executeQuery(sql);
	          
              while(rs.next()) {
            	  int id = rs.getInt("id_usuario");
            	  String nombre = rs.getString("nombre");
            	  String clave = rs.getString("clave");
            	  int rut = rs.getInt("rut");
            	  String dv = rs.getString("dv");
            	  
            	  Usuario u = new Usuario(id, nombre, clave, rut, dv);
            	  usuarios.add(u);
              }
  
		}catch(SQLException e) {
			e.printStackTrace();
		
		}
		
		return usuarios;
		
	}

}
