package servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import dto.Role;
import dto.UserDTO;

/**
 * Servlet implementation class Servlet
 */
@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//dejar como atributo valores de la enumeración
		request.setAttribute("roles", Arrays.asList(Role.values()));
		
		
		//request dispatcher, llamar o invocar a vista JSP
				//RequestDispatcher dispatcher = request.getRequestDispatcher("registro.jsp");
			//	dispatcher.forward(request, response);
				
				
request.getRequestDispatcher("registro.jsp").forward(request, response);
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	//recuperar valores del formulario
		String nombre =request.getParameter("nombre");
		String username =request.getParameter("username");
		String mail =request.getParameter("mail");
		String password =request.getParameter("password");
		String rol =request.getParameter("rol");
		
		
		Role role = Role.valueOf(rol);
		
		List<Role> roles = new ArrayList();
		roles.add(role);
		
		UserDTO userDTO =new UserDTO(nombre, username, mail, password, roles);
		
		request.setAttribute("nombre", userDTO.getName());
		request.setAttribute("username", userDTO.getUsername());	
		request.setAttribute("mail", userDTO.getEmail());
	
		request.getRequestDispatcher("confirmacion.jsp").forward(request, response);
	}

}
