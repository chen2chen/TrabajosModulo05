package dao;

import java.util.List;

import model.Departamento;

public interface DepartamentoDAO {
	public List<Departamento> obtieneDepartamento() throws ClassNotFoundException;

}
