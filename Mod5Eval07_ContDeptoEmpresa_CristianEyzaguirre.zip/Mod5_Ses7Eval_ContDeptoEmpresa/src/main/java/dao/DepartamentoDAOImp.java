package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Departamento;


public class DepartamentoDAOImp implements DepartamentoDAO{
	
	//establecer parametros de conexion
			private static final String URL="jdbc:oracle:thin:@localhost:1539:xe";
			private static final String USER ="empleadoApp";
			private static final String PASSWORD ="12345";
			
			//definir la conexión
			public Connection conectar() throws SQLException{
				return DriverManager.getConnection(URL, USER, PASSWORD);
				
			}

	@Override
	public List<Departamento> obtieneDepartamento() throws ClassNotFoundException {
		
		List<Departamento> departamentos = new ArrayList<>();
		String sql="select * from departamento";
		
		Connection conn= null;
		Statement stmt= null;
		
		try {
	         //Cargar el driver
			 Class.forName("oracle.jdbc.OracleDriver");
			
			 //conectar a la BD
	          conn = conectar();
	          
	          stmt = conn.createStatement();
	          ResultSet rs = stmt.executeQuery(sql);
	          
	          while(rs.next()) {
	        	  int numdepto = rs.getInt("numdepto");
	        	//  String numdepto = rs.getString("numdepto");
	        	 
	        	  
	        	  Departamento d = new Departamento(numdepto);
	        	  departamentos.add(d);
	          }

		}catch(SQLException e) {
			e.printStackTrace();
		
		}
		
		return departamentos;
	}

}
