package dao;

import java.util.List;

import model.Empleado;

public interface EmpleadoDAO {
	public List<Empleado> obtieneEmpleado() throws ClassNotFoundException;

}


