package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Empleado;


public class EmpleadoDAOImp implements EmpleadoDAO{
	
	//establecer parametros de conexion
		private static final String URL="jdbc:oracle:thin:@localhost:1539:xe";
		private static final String USER ="empleadoApp";
		private static final String PASSWORD ="12345";
		
		//definir la conexión
		public Connection conectar() throws SQLException{
			return DriverManager.getConnection(URL, USER, PASSWORD);
			
		}
	


@Override
public List<Empleado> obtieneEmpleado() throws ClassNotFoundException {
	
	List<Empleado> empleados = new ArrayList<>();
	String sql="SELECT e.numempleado, e.nombre, d.numdepto "
			+ "FROM empleado e "
			+ "INNER JOIN departamento d ON e.id_depto = d.id_depto "
			+ "ORDER BY e.nombre";
	
	
	Connection conn= null;
	Statement stmt= null;
	
	try {
         //Cargar el driver
		 Class.forName("oracle.jdbc.OracleDriver");
		
		 //conectar a la BD
          conn = conectar();
          
          stmt = conn.createStatement();
          ResultSet rs = stmt.executeQuery(sql);
          
          while(rs.next()) {
        	  int numempleado = rs.getInt("numempleado");
        	  String nombre = rs.getString("nombre");
        	  int numdepto = rs.getInt("numdepto");
        	  
        	  Empleado e = new Empleado(numempleado, nombre, numdepto);
        	  empleados.add(e);
          }

	}catch(SQLException e) {
		e.printStackTrace();
	
	}
	
	return empleados;
}

}


