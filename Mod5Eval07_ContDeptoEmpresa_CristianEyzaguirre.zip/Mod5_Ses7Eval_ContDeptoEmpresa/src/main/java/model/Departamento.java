package model;

public class Departamento {
	private int numdepto;

	public Departamento(int numdepto) {
		super();
		this.numdepto = numdepto;
	}

	public int getNumdepto() {
		return numdepto;
	}

	public void setNumdepto(int numdepto) {
		this.numdepto = numdepto;
	}

	@Override
	public String toString() {
		return "Departamento [numdepto=" + numdepto + "]";
	}
	
	

}
