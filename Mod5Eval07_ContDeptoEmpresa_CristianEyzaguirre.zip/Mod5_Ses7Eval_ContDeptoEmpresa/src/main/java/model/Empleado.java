package model;

public class Empleado {
	private int numempleado;
	private String nombre;
	private int numdepto;
	
	
	public Empleado(int numempleado, String nombre, int numdepto) {
		this.numempleado = numempleado;
		this.nombre = nombre;
		this.numdepto = numdepto;
	}


	public int getNumempleado() {
		return numempleado;
	}


	public void setNumempleado(int numempleado) {
		this.numempleado = numempleado;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public int getNumdepto() {
		return numdepto;
	}


	public void setNumdepto(int numdepto) {
		this.numdepto = numdepto;
	}


	@Override
	public String toString() {
		return "Empleado [numempleado=" + numempleado + ", nombre=" + nombre + ", numdepto=" + numdepto + "]";
	}
	
	
}
	
	