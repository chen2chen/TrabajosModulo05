package eval2;

public class ProductoServlet {
	private String nombre, descripcion;
	private int valor, cantidad, total;
	
	public ProductoServlet(String nombre, String descripcion, int valor, int cantidad, int total) {
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.valor = valor;
		this.cantidad = cantidad;
		this.total = total;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public int getValor() {
		return valor;
	}
	public void setValor(int valor) {
		this.valor = valor;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "Producto [nombre=" + nombre + ", descripcion=" + descripcion + ", valor=" + valor + ", cantidad="
				+ cantidad + ", total=" + total + "]";
	}
	
	
	
	

}
