package eval2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class Servlet2
 */
@WebServlet("/Servlet2")
public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Servlet2() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nombre = request.getParameter("nombre");
		String direccion = request.getParameter("direccion");
		
		//Recuperar el valor de cada celda de la tabla
		String prodP1 = request.getParameter("prodP1");
		String descP1 = request.getParameter("descP1");
		int valorP1 =Integer.parseInt(request.getParameter("valorP1"));
		int cantP1 = Integer.parseInt(request.getParameter("cantP1"));
		
		String prodP2 = request.getParameter("prodP2");
		String descP2 = request.getParameter("descP2");
		int valorP2 = Integer.parseInt(request.getParameter("valorP2"));
		int cantP2 = Integer.parseInt(request.getParameter("cantP2"));
		
		String prodP3 = request.getParameter("prodP3");
		String descP3 = request.getParameter("descP3");
		int valorP3 = Integer.parseInt(request.getParameter("valorP3"));
		int cantP3 = Integer.parseInt(request.getParameter("cantP3"));
		
		String prodP4 = request.getParameter("prodP4");
		String descP4 = request.getParameter("descP4");
		int valorP4 = Integer.parseInt(request.getParameter("valorP4"));
		int cantP4 = Integer.parseInt(request.getParameter("cantP4"));
		
		List<ProductoServlet>  productos = new ArrayList<>();

		productos.add(new ProductoServlet(prodP1, descP1, valorP1, cantP1, valorP1*cantP1));
		productos.add(new ProductoServlet(prodP2, descP2, valorP2, cantP2, valorP2*cantP2));
		productos.add(new ProductoServlet(prodP3, descP3, valorP3, cantP3, valorP3*cantP3));
		productos.add(new ProductoServlet(prodP4, descP4, valorP4, cantP4, valorP4*cantP4));
	
		//calcular total
		int total = valorP1*cantP1 +valorP2*cantP2+valorP3*cantP3+valorP4*cantP4;
		double descuento = 0.1*total;
		double totalDescuento =0.9*total;
		
		//variables que se envian al factura.jsp
	    request.setAttribute("productos", productos);
	    request.setAttribute("nombre", nombre);
	    request.setAttribute("direccion", direccion);
	    request.setAttribute("total", total);
	    request.setAttribute("descuento", descuento);
	    request.setAttribute("totalDescuento", totalDescuento);
	    
	  //reedigir al JSP
	    request.getRequestDispatcher("Factura.jsp").forward(request, response);
	
	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
