package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Departamento;

public class DepartamentoDAO {
	
		//establecer los parametros de conexión con BD
			private static final String URL="jdbc:oracle:thin:@localhost:1539:xe";
			private static final String USER="APPWEB";
			private static final String PASSWORD="12345";
			
			//definir la conexión
			public Connection conectar() throws SQLException{
				return DriverManager.getConnection(URL, USER, PASSWORD);
				}
			
			//definir método listar
			public List<Departamento> listar() throws ClassNotFoundException{
			
			      List<Departamento> departamentos = new ArrayList<>();
			      String sql= "SELECT * FROM DEPARTAMENTO";
			      
			      Connection conn = null;
			      Statement stmt = null;
			      
			      try {
			    	  //Cargar driver
			    	  Class.forName("oracle.jdbc.OracleDriver");
			    	  //conectar con BD
			    	  conn = conectar();
			    	  //ejecutar sentencia
			    	  stmt = conn.createStatement();
			    	  ResultSet rs = stmt.executeQuery(sql);
			    	  //llenar arraylist con resultados de consulta
			    	  while(rs.next()) {
			    		  int numero = rs.getInt("NUMDEPTO");
			    		  String nombre = rs.getString("NOMDEPTO");
			    		  String ubicacion = rs.getString("UBICACIONDPTO");
			    		  
			    		  Departamento d = new Departamento(numero, nombre, ubicacion);
			    		  departamentos.add(d);
			    	  }
			    	   
			      }catch(SQLException e) {
			    	  
			      }
			      
			       return departamentos;
			}

}
