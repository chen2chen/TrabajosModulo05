package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.Usuario;

public class UsuarioDAO {
	
	//establecer los parametros de conexión con BD
			private static final String URL="jdbc:oracle:thin:@localhost:1539:xe";
			private static final String USER="APPWEB";
			private static final String PASSWORD="12345";
			
			//definir la conexión
			public Connection conectar() throws SQLException{
				return DriverManager.getConnection(URL, USER, PASSWORD);
				}
			
			//definir método buscar
			public Usuario buscar(int rut, String clave) throws ClassNotFoundException{
			
			      Usuario usuario = null;
			      String sql= "SELECT * FROM USUARIO WHERE RUT=" + rut +" AND CLAVE='"+ clave +"'";
			      
			      Connection conn = null;
			      Statement stmt = null;
			      
			      try {
			    	  //Cargar driver
			    	  Class.forName("oracle.jdbc.OracleDriver");
			    	  //conectar con BD
			    	  conn = conectar();
			    	  //ejecutar sentencia
			    	  stmt = conn.createStatement();
			    	  ResultSet rs = stmt.executeQuery(sql);
			    	  //llenar arraylist con resultados de consulta
			    	  while(rs.next()) {
			    		  int rutUsuario = rs.getInt("rut");
			    		  String nombreUsuario = rs.getString("nombre");
			    		  String claveUsuario = rs.getString("clave");
			    		  
			    		  usuario = new Usuario(rutUsuario, claveUsuario, nombreUsuario);
			    	  }
			    	   
			      }catch(SQLException e) {
			    	  
			      }
			      
			       return usuario;
			}
		

}
